# Importieren Sie die erforderlichen Bibliotheken
from sklearn.feature_extraction import DictVectorizer
import csv
from sklearn import preprocessing
from sklearn import tree

f = open("/home/schmidt/EXAgT/EIP_Stickstoff/SW-Düngeberatungssystem/Entscheidungsmatrix.csv")

#Ladendatei laden
load_file = open(r"/home/schmidt/EXAgT/EIP_Stickstoff/SW-Düngeberatungssystem/Entscheidungsmatrix.csv")  
reader = csv.reader(load_file, delimiter=';')  #Laden von Daten
headers = reader.__next__()   #Lesen Sie die erste Zeile
print(headers)
#Versuchen Sie, das Ergebnis zu drucken, oder verwenden Sie es als Indikator, um die Daten erfolgreich zu laden

lables = []    # Wird zum Speichern der Tag-Instanz verwendet, dh ob in diesem Beispiel ein Computer gekauft werden soll
feature = []   # Zum Speichern von Funktionen

#reader Der zurückgegebene Wert ist eine Liste jeder Zeile in der CSV-Datei, und der von jeder Zeile gelesene Wert wird als Liste zurückgegeben
for row in reader:
    
    lables.append(row[len(row)-1])
    features = {}
    for each in range(1,len(row)-1):
        features[headers[each]] = row[each]
    feature.append(features)

vec = DictVectorizer()
x = vec.fit_transform(feature).toarray()
print('X nach Merkmalsextraktion'+'\n'+str(x))
#print(headers)
lab = preprocessing.LabelBinarizer()
y = lab.fit_transform(lables)
print('Y'+'\n'+str(y))

result = tree.DecisionTreeClassifier(criterion='entropy')
#Verwenden Sie die Auswahlkriterien für Features als Entropie. Der Standardwert ist der Gini-Koeffizient "gini".
result.fit(x,y)
# print('result'+str(result))
with open('tree1.dot','w') as f:
    f = tree.export_graphviz(result,out_file=f,feature_names=vec.get_feature_names())
# In Datei speichern